package project;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class Shoppingcart {
    private List<Item> items;

    public Shoppingcart() {
        items = new ArrayList<>();
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }

    public double calculateTotal(Predicate<Item> filter) {
        return items.stream()
                .filter(filter)
                .mapToDouble(Item::getPrice)
                .sum();
    }

    public class CartItem {
        private Item item;

        public CartItem(Item item) {
            this.item = item;
        }

        public Item getItem() {
            return item;
        }
    }
}
