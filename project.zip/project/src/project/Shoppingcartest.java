package project;

public class Shoppingcartest {

	public static void main(String[] args) {
		        Shoppingcart cart = new Shoppingcart();

		        Item apple = new Item("Apple", 0.99);
		        Item banana = new Item("Banana", 0.59);
		        Item orange = new Item("Orange", 0.79);

		        cart.addItem(apple);
		        cart.addItem(banana);
		        cart.addItem(orange);

		        // Calculate total price of all items
		        double total = cart.calculateTotal(item -> true);
		        System.out.println("Total Price: $" + total);

		        // Calculate total price of items that cost more than $0.60
		        double filteredTotal = cart.calculateTotal(item -> item.getPrice() > 0.60);
		        System.out.println("Total Price of items > $0.60: $" + filteredTotal);
		    }
		}
