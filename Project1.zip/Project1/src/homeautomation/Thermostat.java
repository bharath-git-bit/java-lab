package homeautomation;

public class Thermostat {
    private int temperature;

    public void setTemperature(int temperature) {
        this.temperature = temperature;
        System.out.println("Thermostat set to " + temperature + " degrees");
    }

    public int getTemperature() {
        return temperature;
    }
}

