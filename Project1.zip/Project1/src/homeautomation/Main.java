package homeautomation;

public class Main {
    public static void main(String[] args) {
        Light livingRoomLight = new Light();
        Thermostat thermostat = new Thermostat();

        Command lightOn = new LightOnCommand(livingRoomLight);
        Command lightOff = new LightOffCommand(livingRoomLight);
        Command setTemperature = new ThermostatSetCommand(thermostat, 72);

        RemoteControl remote = new RemoteControl();

        remote.setCommand(lightOn);
        remote.pressButton(); 
        remote.pressUndo();  

        remote.setCommand(lightOff);
        remote.pressButton();  
        remote.pressUndo();   

        remote.setCommand(setTemperature);
        remote.pressButton(); 
        remote.pressUndo();   
    }
}

